<?php
/**
 * Plugin Name:       CUSTOME HOKKS
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Custom Plugin to exceute crud opreation in Wordpress.
 * Version:           1.00
 * Requires at least: 5.0
 * Requires PHP:      7.0
 * Author:           Anshul Mishra
 * Author URI:        https://facebook.com/Er Anshul Mishra
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       custome hooks
 */

 function wp_init_hooks(){
    register_post_type( 'movies',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Custome_post' ),
                'singular_name' => __( 'Movie' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'movies'),
            'show_in_rest' => true,
  
        )
    );
 }
 add_action("init","wp_init_hooks");

 function initlization_hook(){
    //  die("this is the initlization hook when plugin activated this will fire");
 }
 add_action("init","initlization_hook");



//  function remove_dashboard_widgets(){
//     global $wp_meta_boxes;
//     foreach( $wp_meta_boxes["dashboard"] as $position => $core ){
//         foreach( $core["core"] as $widget_id => $widget_info ){
//             remove_meta_box( $widget_id, 'dashboard', $position );
//         }
//     }
     
// }
// add_action( 'wp_dashboard_setup', 'remove_dashboard_widgets', 1000000 );



// function custom_post_type() {
  
//     // Set UI labels for Custom Post Type
//         $labels = array(
//             'name'                => _x( 'Movies', 'Post Type General Name', 'twentytwentyone' ),
//             'singular_name'       => _x( 'Movie', 'Post Type Singular Name', 'twentytwentyone' ),
//             'menu_name'           => __( 'Movies', 'twentytwentyone' ),
//             'parent_item_colon'   => __( 'Parent Movie', 'twentytwentyone' ),
//             'all_items'           => __( 'All Movies', 'twentytwentyone' ),
//             'view_item'           => __( 'View Movie', 'twentytwentyone' ),
//             'add_new_item'        => __( 'Add New Movie', 'twentytwentyone' ),
//             'add_new'             => __( 'Add New', 'twentytwentyone' ),
//             'edit_item'           => __( 'Edit Movie', 'twentytwentyone' ),
//             'update_item'         => __( 'Update Movie', 'twentytwentyone' ),
//             'search_items'        => __( 'Search Movie', 'twentytwentyone' ),
//             'not_found'           => __( 'Not Found', 'twentytwentyone' ),
//             'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwentyone' ),
//         );
          
//     // Set other options for Custom Post Type
          
//         $args = array(
//             'label'               => __( 'movies', 'twentytwentyone' ),
//             'description'         => __( 'Movie news and reviews', 'twentytwentyone' ),
//             'labels'              => $labels,
//             // Features this CPT supports in Post Editor
//             'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
//             // You can associate this CPT with a taxonomy or custom taxonomy. 
//             'taxonomies'          => array( 'genres' ),
//             /* A hierarchical CPT is like Pages and can have
//             * Parent and child items. A non-hierarchical CPT
//             * is like Posts.
//             */
//             'hierarchical'        => false,
//             'public'              => true,
//             'show_ui'             => true,
//             'show_in_menu'        => true,
//             'show_in_nav_menus'   => true,
//             'show_in_admin_bar'   => true,
//             'menu_position'       => 5,
//             'can_export'          => true,
//             'has_archive'         => true,
//             'exclude_from_search' => false,
//             'publicly_queryable'  => true,
//             'capability_type'     => 'post',
//             'show_in_rest' => true,
      
//         );
          
//         // Registering your Custom Post Type
//         register_post_type( 'movies', $args );
      
//     }
      
    /* Hook into the 'init' action so that the function
    * Containing our post type registration is not 
    * unnecessarily executed. 
    */
      
    add_action( 'init', 'custom_post_type', 0 );


    // admin baar menu 
    add_action( 'admin_bar_menu', 'admin_bar_item', 500 );
function admin_bar_item ( WP_Admin_Bar $admin_bar ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $admin_bar->add_menu( array(
        'id'    => 'menu-id',
        'parent' => null,
        'group'  => null,
        'title' => 'custome_menu', //you can use img tag with image link. it will show the image icon Instead of the title.
        'href'  => admin_url('admin.php?page=custom-page'),
        'meta' => [
            'title' => __( 'Custome_menu', 'textdomain' ), //This title will show on hover
        ]
    ) );
}
//////////////
function sample_admin_notice__success() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'Done!', 'sample-text-domain' ); ?></p>
    </div>
    <?php
}
add_action( 'admin_notices', 'sample_admin_notice__success' );
///////////////////////////
function sample_admin_notice__error() {
    $class = 'notice notice-error';
    $message = __( 'Irks! An error has occurred.', 'sample-text-domain' );
 
    printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) ); 
}
add_action( 'admin_notices', 'sample_admin_notice__error' );
//////////////////////////////

function themeslug_enqueue_style() {
    wp_enqueue_style( 'core', 'style.css', false ); 
}
 
function themeslug_enqueue_script() {
    wp_enqueue_script( 'my-js', 'filename.js', false );
}
 
add_action( 'login_enqueue_scripts', 'themeslug_enqueue_style', 10 );
add_action( 'login_enqueue_scripts', 'themeslug_enqueue_script', 1 );

////////////////////
function so_post_40744782( $new_status, $old_status, $post ) {
    if ( $new_status == 'publish' && $old_status != 'publish' ) {
        $author = "foobar";
        $message = "We wanted to notify you a new post has been published.";
        wp_mail($author, "New Post Published", $message);
    }
}
add_action('transition_post_status', 'so_post_40744782', 10, 3 );


/////////////////////////
