
function get_image_priview(event){
    //console.log(event.target.files[0]);
    var image=URL.createObjectURL(event.target.files[0]);
    var imagediv=document.getElementById('priview');
    var newimg=document.createElement('img');
    newimg.src=image;
    imagediv.innerHTML='';
    newimg.width="600";
    newimg.height="100";
    imagediv.appendChild(newimg);
}
