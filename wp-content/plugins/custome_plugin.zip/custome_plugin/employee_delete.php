<?php
//echo "employee delete";
function employee_delete(){
 
    if(isset($_GET['id'])){
        global $wpdb;
        global $table_prifix;
        $table=$table_prifix.'custome_plugin';
        $i=$_GET['id'];
        $wpdb->delete(
            $table,
            array('id'=>$i)
        );
        // $location=admin_url('admin.php?page=Employee_List');
        // wp_redirect($location);
        // $location=admin_url('admin.php?page=Employee_List');
        // wp_redirect($location);
        // wp_redirect( admin_url('admin.php?page=page=Employee_List'),301 );
    }
}
?>