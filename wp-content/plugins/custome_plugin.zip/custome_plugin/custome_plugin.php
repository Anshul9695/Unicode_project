<?php
/**
 * Plugin Name:       CRUD Operation
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Custom Plugin to exceute crud opreation in Wordpress.
 * Version:           1.00
 * Requires at least: 5.0
 * Requires PHP:      7.0
 * Author:           Anshul Mishra
 * Author URI:        https://facebook.com/Er Anshul Mishra
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       crud-plugin
 */

register_activation_hook(__FILE__,'activate_the_plugin');
register_deactivation_hook(__FILE__,'deactivate_the_plugin');

function activate_the_plugin(){
    global $wpdb;
    global $table_prifix;
    $table=$table_prifix.'custome_plugin';
    $sql = "CREATE TABLE IF NOT EXISTS `unicode_project`.$table ( 
    `id` INT(40) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
      PRIMARY KEY (`id`)) ENGINE = InnoDB;";
    $wpdb->query($sql);

}
function deactivate_the_plugin(){
    global $wpdb;
    global $table_prifix;
      $table=$table_prifix.'custome_plugin';
      $sql="DROP TABLE `unicode_project`.$table";
      $wpdb->query($sql);
}
//adding menu for the plugin 
add_action('admin_menu', 'my_plugin_admin_menu');
function my_plugin_admin_menu(){
    add_menu_page('custome_plugin', //page title
    'custome_plugin', //menu title
    'manage_options', //capabilities
    'Employee_Listing', //menu slug
    'employee_list' //function
);
add_submenu_page('Employee_Listing',//parent page slug
'employee_listing',//page title
'Data Listing',//menu titel
'manage_options',//manage optios
'Employee_Listing',//slug
'employee_list'//function
);
    //adding submenu to a menu
    add_submenu_page('Employee_Listing',//parent page slug
        'employee_insert',//page title
        'Insert Data',//menu titel
        'manage_options',//manage optios
        'Employee_Insert',//slug
        'employee_insert'//function
    );
    add_submenu_page( null,//parent page slug
        'employee_update',//$page_title
        'Employee Update',// $menu_title
        'manage_options',// $capability
        'Employee_Update',// $menu_slug,
        'employee_update'// $function
    );
    add_submenu_page( null,//parent page slug
        'employee_delete',//$page_title
        'Employee Delete',// $menu_title
        'manage_options',// $capability
        'Employee_Delete',// $menu_slug,
        'employee_delete'// $function
    );
}


define('ROOTDIR', plugin_dir_path(__FILE__));
require_once(ROOTDIR . 'employee_list.php');
require_once (ROOTDIR.'employee_insert.php');
require_once (ROOTDIR.'employee_update.php');
require_once (ROOTDIR.'employee_delete.php');

?>