<?php
function employee_list() {
    ?>
    <style>
        table {
            border-collapse: collapse;
        }
        table, td, th {
            border: 1px solid black;
            padding: 20px;
            text-align: center;
        }
    </style>
    <div class="wrap">
        <table>
            <thead>
            <tr>
                <th>S.No</th>
                <th>User_ID</th>
                <th>Name</th>
                <th>email</th>
                <th>phone</th>
                <th>Address</th>
                <th>Update</th>
                <th>Delete</th>

                <th>Current Login User InFo</th>
            </tr>
            </thead>
            <tbody>
            <?php
         
     global $wpdb;
     global $table_prifix;
     $table=$table_prifix.'custome_plugin';
            $table_data = $wpdb->get_results("SELECT id,name,email,phone,address from $table");

            //printing the current user info 
            global $current_user;
            wp_get_current_user();
        
            foreach ($table_data  as $key=>$data) {
                ?>
                <tr>
                    <td><?= $key+1;?></td>
                    <td><?= $data->id;?></td>
                   
                    <td><?= $data->name; ?></td>
                    <td><?= $data->email; ?></td>
                    <td><?= $data->phone; ?></td>
                    <td><?= $data->address; ?></td>
                    <td><a href="<?php echo admin_url('admin.php?page=Employee_Update&id=' . $data->id); ?>">Update</a> </td>
                    <td><a href="<?php echo admin_url('admin.php?page=Employee_Delete&id=' . $data->id); ?>"> Delete</a></td>
            <?php } ?>
            <td><?= $current_user->ID."<br/>".$current_user->user_login."<br/>".$current_user->user_email 
            ."<br/>".$current_user->display_name."<br/>".$current_user->user_registered ?></td>
            </tr>
            </tbody>
           
        </table>
    </div>
    <?php
    
}
add_shortcode('short_employee_list', 'employee_list');
?>

