<?php
//echo "update page";
function employee_update(){
    //echo "update page in";
 
    global $wpdb;
    global $table_prifix;
    $table=$table_prifix.'custome_plugin';

    $i=$_GET['id'];
  
    $usersData = $wpdb->get_results("SELECT id,name,email,phone,address from  $table where id=$i");
    // print_r($userData);
    // // die;
    // echo $userData[0]->id;
    foreach( $usersData as $userData){
    ?>
    <table>
        <thead>
        <tr>
            <th></th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <form name="frm" action="#" method="post">
            <input type="hidden" name="id" value="<?= $userData->id; ?>">
            <tr>
                <td>Name:</td>
                <td><input type="text" name="name" value="<?= $userData->name; ?>"></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><input type="text" name="email" value="<?= $userData->email; ?>"></td>
            </tr>
            <tr>
                <td>Phone:</td>
                <td><input type="text" name="phone" value="<?= $userData->phone; ?>"></td>
            </tr>
            <tr>
                <td>Address:</td>
                <td><input type="text" name="address" value="<?= $userData->address; ?>"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Update" name="update"></td>
            </tr>
        </form>
        </tbody>
    </table>
    <?php
}
}

if(isset($_POST['update']))
{
    global $wpdb;
    global $table_prifix;
    $table=$table_prifix.'custome_plugin';

    $id=$_POST['id'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $wpdb->update(
        $table,
        array(
            'name'=>$name,
            'email'=>$email,
            'phone'=>$phone,
            'address'=>$address
        ),
        array(
            'id'=>$id
        )
    );

}
?>
