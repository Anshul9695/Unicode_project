<?php
if(!defined("ABSPATH")){
    header("location: /Unicode_project");
}

//   no access 
?>