    <!-- Side widgets-->
    <div class="col-lg-4">
                    <!-- Search widget-->
                <?php dynamic_sidebar('main-sidebar')?>
                </div>